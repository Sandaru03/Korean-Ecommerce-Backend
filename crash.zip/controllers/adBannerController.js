const AdBanner = require('../models/AdBanner');
const { deleteLocalFile } = require('../utils/localFileHelper');

// Get all ad banners (For Admin), optionally filtered by slot
exports.getAllAdBanners = async (req, res) => {
    try {
        const where = {};
        if (req.query.slot) where.slot = parseInt(req.query.slot);
        const banners = await AdBanner.findAll({ where, order: [['order', 'ASC']] });
        res.json({ success: true, banners });
    } catch (error) {
        console.error("Error fetching ad banners:", error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Get only active ad banners (For Frontend Slider)
exports.getActiveAdBanners = async (req, res) => {
    try {
        const slot = parseInt(req.query.slot) || 1;
        const banners = await AdBanner.findAll({ 
            where: { isActive: true, slot }, 
            order: [['order', 'ASC']] 
        });
        res.json({ success: true, banners });
    } catch (error) {
        console.error("Error fetching active ad banners:", error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Create a new ad banner
exports.createAdBanner = async (req, res) => {
    try {
        const { image, link, isActive, order, slot } = req.body;
        const banner = await AdBanner.create({ image, link, isActive, order, slot: slot || 1 });
        res.status(201).json({ success: true, banner });
    } catch (error) {
        console.error("Error creating ad banner:", error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Update an ad banner
exports.updateAdBanner = async (req, res) => {
    try {
        const { id } = req.params;
        const { image, link, isActive, order, slot } = req.body;
        const banner = await AdBanner.findByPk(id);
        
        if (!banner) return res.status(404).json({ success: false, message: 'Banner not found' });
        
        // Delete old image if a new one is provided or it is cleared
        if (image !== undefined && image !== banner.image && banner.image) {
            await deleteLocalFile(banner.image, 'image');
        }

        await banner.update({ image, link, isActive, order, ...(slot !== undefined && { slot }) });
        res.json({ success: true, banner });
    } catch (error) {
        console.error("Error updating ad banner:", error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};

// Delete an ad banner
exports.deleteAdBanner = async (req, res) => {
    try {
        const { id } = req.params;
        const banner = await AdBanner.findByPk(id);
        
        if (!banner) return res.status(404).json({ success: false, message: 'Banner not found' });

        // Delete image from local storage before removing DB record
        if (banner.image) {
            await deleteLocalFile(banner.image, 'image');
        }

        await banner.destroy();
        res.json({ success: true, message: 'Banner deleted successfully' });
    } catch (error) {
        console.error("Error deleting ad banner:", error);
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
